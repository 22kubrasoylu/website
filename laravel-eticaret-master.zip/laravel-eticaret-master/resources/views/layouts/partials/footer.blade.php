<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-6">Eticaret Yazılımı &copy; 2018</div>
            <div class="col-md-6 text-right">
                <a href="https://www.udemy.com/laravel-ile-sifirdan-eticaret-projesi">Udemy Kurs Sayfası</a> |
                <a href="http://www.uzaktankurs.com">Uzaktan Kurs</a>
            </div>
        </div>
    </div>
</footer>